#
# Cookbook:: msrcosmos1
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.

apt_update 'Update the apt cache daily' do
  frequency 86_400
  action :periodic
end

# Docker Composer
    execute 'run a script' do
    user 'root'
    command <<-EOH
     curl -L https://github.com/docker/compose/releases/download/1.24.0-rc1/docker-compose-`uname -s`-`uname -m` -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    EOH
end



# Docker
execute 'run a script' do
  user 'root'
  command <<-EOH
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
  add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
  apt-get update
  EOH
end


package 'docker-ce' do
        action :install
end


# Install Git
package 'git' do
        action :install
end

# Install OpenSSL 
  execute 'run a script' do
  user 'root'
  command <<-EOH
  if [ ! $(openssl version -a | grep OpenSSL | awk '{print $1}') ]; then
  cd /tmp
  #wget https://www.openssl.org/source/openssl-1.1.1.tar.gz
  wget https://www.openssl.org/source/openssl-1.1.1b.tar.gz
  tar xvf openssl-1.1.1b.tar.gz
  cd openssl-1.1.1b
   ./config -Wl,--enable-new-dtags,-rpath,'$(LIBRPATH)'
  #make
  #make install
  fi
  EOH
end

# Install nvm
execute 'run a script' do
  user 'root'
  command <<-EOH
  if [ ! -d ~/.nvm ]; then

  curl -sL https://raw.githubusercontent.com/creationix/nvm/v0.33.2/install.sh | bash
  #source ~/.nvm/nvm.sh
  #source ~/.profile
  #source ~/.bashrc
  #nvm install 8.12.0
  fi
  EOH
end

# Install node
execute 'run a script' do
  user 'root'
  command <<-EOH
  curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -
  EOH
end

package 'nodejs' do
        action :install
end

