#
# Cookbook:: msrcosmos2
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.
apt_update 'Update the apt cache daily' do
  frequency 86_400
  action :periodic
end


execute 'run a script' do
  user 'root'
  command <<-EOH
 
  if [ ! -d /root/dockercompose ]; then
  mkdir /root/dockercompose
  mkdir /root/dockercompose/webapp
  
  fi
  EOH
end


template '/root/dockercompose/webapp/index.html' do
  source 'index.html.erb'
end

template '/root/dockercompose/webapp/Dockerfile' do
  source 'Dockerfile.erb'
end

template '/root/dockercompose/docker-compose.yml' do
  source 'docker-compose.yml.erb'
end


 execute 'run a script' do
  user 'root'
  command <<-EOH
  cd /root/dockercompose
  docker-compose build
  docker-compose up -d
EOH
end
