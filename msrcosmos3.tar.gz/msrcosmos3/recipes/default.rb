#
# Cookbook:: msrcosmos3
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.
apt_update 'Update the apt cache daily' do
  frequency 86_400
  action :periodic
end


execute 'run a script' do
  user 'root'
  command <<-EOH
 
  if [ ! -d /root/couchdb ]; then
  mkdir /root/couchdb
  fi
  EOH
end

template '/root/couchdb/docker-compose.yml' do
  source 'docker-compose.yml.erb'
end


 execute 'run a script' do
  user 'root'
  command <<-EOH
  cd /root/couchdb
  docker-compose up -d
EOH
end
